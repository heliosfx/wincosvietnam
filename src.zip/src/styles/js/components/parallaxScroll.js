/**
 * parallaxSroll
 *
 * @requires jquery.parallax-scroll-master
*/
Ecsgroup.parallaxScroll = function () {
    if ($.fn.ParallaxScroll) {
        ParallaxScroll.init()
    }
}