// jQuery(document).ready(function() {
//     var swiperBlog = new Swiper('#blog-swiper', {
//       lazy: true,
//       breakpoints: {
//         300: {
//           slidesPerView: 1,
//           spaceBetween: 30,
//         },
//         760: {
//           slidesPerView: 2.5,
//           spaceBetween: 20,
//         },
//         1000: {
//           slidesPerView: 2.5,
//           spaceBetween: 30,
//         },
//         1200: {
//           slidesPerView: 3.5,
//           spaceBetween: 20,
//         },
//       },
//       pagination: {
//         el: '.blog-swiper-pagination',
//         clickable: true,
//       },
//       navigation: {
//         nextEl: '.blog-swiper-button-next',
//         prevEl: '.blog-swiper-button-prev',
//       },
//     });
// });
(function ($) {
    Ecsgroup.initPage = function () {
        // Page
        // Default
    };
  })(jQuery);
  