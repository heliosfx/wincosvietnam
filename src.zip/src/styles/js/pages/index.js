(function ($) {
  Ecsgroup.initLayout = function () {
  };
  Ecsgroup.initPage = function () {
  };
})(jQuery);